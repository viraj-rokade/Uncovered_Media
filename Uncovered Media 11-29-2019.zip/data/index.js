const user_functions_call = require("./user_functions");
//const posts_call = require("./posts");
//const events_call = require("./events");
//const petitions_call = require("./petitions");
//const emergencies_call = require("./emergencies");

module.exports = {
  user_function: user_functions_call
  //posts: posts_call,
  //events: events_call,
  //petitions: petitions_call,
  //emergencies: emergencies_call
};