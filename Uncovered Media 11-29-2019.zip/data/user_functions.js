const collections = require('../db/collections');
const userData = collections.user_reg_data;
const mongodb = require("mongodb");
const bcrypt = require('bcryptjs');

let exportedMethods = {

    async createUser(fname, lname, eid, pass, phone) {
        const hashP = bcrypt.hashSync(pass, 10);
        const d = new Date();
        const month = d.getMonth()+1;
        const curr_date = month+"/"+d.getDate()+"/"+d.getFullYear();
        const userCollection = await userData();

        const newUser = {
            f_name: fname,
            l_name: lname,
            email_id: eid,
            hashed_pass: hashP,
            phone_no: phone,
            address: null,
            city: null,
            state: null,
            country: null,
            zip: null,
            dob: null,
            gender: null,
            profile_img_name: null,
            profile_img_format: null,
            reg_date: curr_date,
            fuck: "sid"
        };

        const newInsertInformation = await userCollection.insertOne(newUser);
        if (newInsertInformation.insertedCount === 0) return false;
        return true;
    },

    async userExistsCheck(email){
        const userCollection = await userData();
        const userPresentInfo = await userCollection.findOne({ email_id: email });

        if (!userPresentInfo)
        {
           return false;
        }
        else 
        {
            return true;
        }   
    },

    async getUserByID(id){   
        const userCollection = await userData();
        const userPresentInfo = await userCollection.findOne({ _id: mongodb.ObjectID(id) });
        return userPresentInfo;
    },

    async loginChecker(email, password){   
       
        const userCollection = await userData();
        const userDataPresent = await userCollection.findOne({ email_id: email });
        if(userDataPresent.email_id===email)
        {
            let passCheck = await bcrypt.compareSync(password, userDataPresent.hashed_pass);
            if(passCheck)
            {
                return userDataPresent._id;
            }
            else
            {
                return -1;
            }
        }
        else
        {
            return -1;
        }
    }

        

};
module.exports = exportedMethods;