function cnf_pass_check()
{
    let password = document.getElementById("password").value;
    let confirm_password = document.getElementById("confirm_password").value;

    if(password!=confirm_password) {
            document.getElementById("err_msg").innerHTML="Password is not matching!";
            document.getElementById('reg_btn').disabled = true;
    } 
    else
    {
        document.getElementById("err_msg").innerHTML="";
        document.getElementById('reg_btn').disabled = false;
    }
}