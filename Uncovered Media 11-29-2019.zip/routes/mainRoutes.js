const express = require("express");
const router = express.Router();
const data = require("../data");
const userData = data.user_function;








router.get('/', async (req, res) => {
    try {
        if (req.session.userId) {
            return res.redirect('/home');
        } else {
            return res.render('display/login',{keywords: "UNCOVERED MEDIA: Login"});
        }
    } catch (e) {
        res.status(404).json({ error: e.message });
    }
})

router.get('/login', async (req, res) => {
    return res.redirect("/"); 
})

router.get('/registration', async (req, res) => {
    return res.render('display/registration',{keywords: "UNCOVERED MEDIA: Register"});
})    

router.post('/registration', async (req, res) => {
    try {
        let formData = req.body;

        let emailCheck = await userData.userExistsCheck(formData.email);
        if(emailCheck==true)
        {
            res.status(401).render('display/registration', { error: "User already exist with that email!" });
        }
        else
        {
            let userCreated = await userData.createUser(formData.firstname, formData.lastname, formData.email, formData.password, formData.phoneno);
            if (userCreated==true) 
            {
                return res.status(200).render('display/registration', { regsucc: "Registration Successful! " });
            } else 
            {
                res.status(401).render('display/registration', { error: "New User Creation Failed! Try Again" });
            }
        }
    } catch (e) {
        res.status(404).json({ error: e.message });
    }
})

router.post('/login', async (req, res) => {
    try {
        let formData = req.body;
        let isValidUser = await userData.loginChecker(formData.email, formData.password);
        if (isValidUser!=-1) {
            req.session.userId = isValidUser;
            req.session.AuthCookie = req.sessionID;
            return res.status(200).redirect("../home");
        } else {
            res.status(401).render('display/login', { error: "Invalid Credentials!" });
        }
    } catch (e) {
        res.status(404).json({ error: e.message });
    }
})

router.get('/home', async (req, res) => {
    try {
        let session_ID = req.session.userId;
        const userDetails =await userData.getUserByID(session_ID);
        return res.status(200).render("display/home", {firstName: userDetails.f_name, lastName: userDetails.l_name, keywords: "UNCOVERED MEDIA: Home"});
    } catch (e) {
        res.status(404).json({ error: e.message });
    }
})

router.get('/error',async (req, res) => {
    return res.render("display/error", {keywords:"error page!"})
})

router.get('/regsucc', async (req, res) => {
    return res.redirect("/"); 
})

router.get('/logout', async (req, res) => {
   
    req.session.destroy(function() {
        res.clearCookie('AuthCookie');
        return res.redirect("/");
      });
})
module.exports = router;